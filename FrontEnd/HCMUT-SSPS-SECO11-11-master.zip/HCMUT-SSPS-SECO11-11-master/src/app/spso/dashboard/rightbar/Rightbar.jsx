import styles from './rightBar.module.css'

const RightBar = () => {
    return ( 
        <div className={styles.container}>
            <div className={styles.item}>
                <div>
                    
                </div>
            </div>
        </div>
    );
}
 
export default RightBar;