import styles from './page.module.css';

const History = () => {
    return ( 
        <div>
            History
        </div>
    );
}
 
export default History;