import styles from './page.module.css';

const Setting = () => {
    return ( 
        <div>
            Setting
        </div>
    );
}
 
export default Setting;