import styles from './page.module.css';

const Statistics = () => {
    return ( 
        <div>
            Statistics
        </div>
    );
}
 
export default Statistics;