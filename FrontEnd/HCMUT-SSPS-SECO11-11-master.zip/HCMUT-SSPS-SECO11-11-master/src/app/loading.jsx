import styles from './page.module.css';

const Loading = () => {
    return (
        <div className='home container'>
            <h1>Loading</h1>
        </div>
    );
}
export default Loading;
